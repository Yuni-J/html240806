/*
주석 외부파일 자바스크립트
*/
 console.log("외부파일 자바스크립트 영역");

 function mySecondFuction(){
    console.log("두번째 함수 외부 let.js 파일에 위치");
 }